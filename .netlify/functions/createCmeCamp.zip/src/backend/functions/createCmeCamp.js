var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var createCmeCamp_exports = {};
__export(createCmeCamp_exports, {
  default: () => createCmeCamp_default,
  handler: () => handler
});
module.exports = __toCommonJS(createCmeCamp_exports);
var import_db = require("../lib/db.js");
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { org_id, name, start_date, end_date, location, expected_attendees, created_by } = JSON.parse(event.body);
    if (!org_id || !name || !start_date || !end_date) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Organization ID, name, start date, and end date are required" })
      };
    }
    const result = await (0, import_db.query)(
      `INSERT INTO cme_camps (org_id, name, start_date, end_date, location, expected_attendees, created_by) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [org_id, name, start_date, end_date, location, expected_attendees, created_by]
    );
    return {
      statusCode: 201,
      body: JSON.stringify({
        message: "CME camp created successfully",
        cmeCamp: result.rows[0]
      })
    };
  } catch (error) {
    console.error("Error creating CME camp:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to create CME camp" })
    };
  }
};
var createCmeCamp_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
