var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var activateLicense_exports = {};
__export(activateLicense_exports, {
  default: () => activateLicense_default,
  handler: () => handler
});
module.exports = __toCommonJS(activateLicense_exports);
var import_db = require("../lib/db.js");
const handler = async (event, context) => {
  if (event.httpMethod !== "PUT") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { license_id, activated_by } = JSON.parse(event.body);
    if (!license_id) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "License ID is required" })
      };
    }
    const result = await (0, import_db.query)(
      `UPDATE licenses 
       SET status = $1, activated_by = $2, activation_date = NOW() 
       WHERE id = $3 RETURNING *`,
      ["active", activated_by, license_id]
    );
    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "License not found" })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "License activated successfully",
        license: result.rows[0]
      })
    };
  } catch (error) {
    console.error("Error activating license:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to activate license" })
    };
  }
};
var activateLicense_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
