var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var listLicenses_exports = {};
__export(listLicenses_exports, {
  default: () => listLicenses_default,
  handler: () => handler
});
module.exports = __toCommonJS(listLicenses_exports);
var import_db = require("../lib/db.js");
const handler = async (event, context) => {
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const orgId = event.queryStringParameters?.org_id || event.queryStringParameters?.orgId || event.query?.org_id || event.query?.orgId;
    console.log("Event:", JSON.stringify(event, null, 2));
    console.log("Org ID:", orgId);
    if (!orgId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Organization ID is required" })
      };
    }
    const result = await (0, import_db.query)(
      `SELECT l.*, u.name as created_by_name 
       FROM licenses l 
       LEFT JOIN users u ON l.created_by = u.id 
       WHERE l.org_id = $1 
       ORDER BY l.created_at DESC`,
      [orgId]
    );
    return {
      statusCode: 200,
      body: JSON.stringify(result.rows)
    };
  } catch (error) {
    console.error("Error listing licenses:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to list licenses" })
    };
  }
};
var listLicenses_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
