var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var saveAiConfig_exports = {};
__export(saveAiConfig_exports, {
  default: () => saveAiConfig_default,
  handler: () => handler
});
module.exports = __toCommonJS(saveAiConfig_exports);
var import_db = require("../lib/db.js");
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { orgId, provider, apiKeyHash, model, userId } = JSON.parse(event.body);
    if (!orgId || !provider || !apiKeyHash || !model) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Organization ID, provider, API key, and model are required" })
      };
    }
    const existingConfig = await (0, import_db.query)(
      "SELECT id FROM ai_configurations WHERE org_id = $1 AND provider = $2",
      [orgId, provider]
    );
    let result;
    if (existingConfig.rows.length > 0) {
      result = await (0, import_db.query)(
        `UPDATE ai_configurations 
         SET api_key_hash = $1, model_name = $2, is_active = true, created_by = $3, updated_at = NOW()
         WHERE org_id = $4 AND provider = $5
         RETURNING *`,
        [apiKeyHash, model, userId, orgId, provider]
      );
    } else {
      result = await (0, import_db.query)(
        `INSERT INTO ai_configurations (org_id, provider, api_key_hash, model_name, created_by)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING *`,
        [orgId, provider, apiKeyHash, model, userId]
      );
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "AI configuration saved successfully",
        config: result.rows[0]
      })
    };
  } catch (error) {
    console.error("Error saving AI configuration:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to save AI configuration" })
    };
  }
};
var saveAiConfig_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
