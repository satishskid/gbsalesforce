var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var aiProxy_exports = {};
__export(aiProxy_exports, {
  default: () => aiProxy_default,
  handler: () => handler
});
module.exports = __toCommonJS(aiProxy_exports);
var import_db = require("../lib/db.js");
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { org_id, user_id, prompt, request_type } = JSON.parse(event.body);
    if (!org_id || !prompt) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Organization ID and prompt are required" })
      };
    }
    const simulatedResponse = {
      id: "simulated-" + Date.now(),
      object: "text_completion",
      created: Math.floor(Date.now() / 1e3),
      model: "gpt-4",
      choices: [
        {
          text: `

This is a simulated response to your prompt: "${prompt}". In a real implementation, this would connect to your configured AI provider.`,
          index: 0,
          logprobs: null,
          finish_reason: "stop"
        }
      ]
    };
    const tokensUsed = prompt.split(" ").length * 1.3;
    const costEstimate = tokensUsed * 3e-5;
    await (0, import_db.query)(
      `INSERT INTO ai_usage_logs (org_id, user_id, provider, model, tokens_used, cost_estimate, request_type) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [org_id, user_id, "openai", "gpt-4", Math.round(tokensUsed), costEstimate.toFixed(6), request_type || "general"]
    );
    return {
      statusCode: 200,
      body: JSON.stringify(simulatedResponse)
    };
  } catch (error) {
    console.error("Error processing AI request:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to process AI request" })
    };
  }
};
var aiProxy_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
