var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var revokeLicense_exports = {};
__export(revokeLicense_exports, {
  default: () => revokeLicense_default,
  handler: () => handler
});
module.exports = __toCommonJS(revokeLicense_exports);
var import_db = require("../lib/db.js");
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { org_id, license_id } = JSON.parse(event.body);
    if (!org_id || !license_id) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Organization ID and License ID are required" })
      };
    }
    const result = await (0, import_db.query)(
      `UPDATE licenses 
       SET status = $1 
       WHERE id = $2 AND org_id = $3 
       RETURNING *`,
      ["revoked", license_id, org_id]
    );
    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "License not found or does not belong to this organization" })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "License revoked successfully",
        license: result.rows[0]
      })
    };
  } catch (error) {
    console.error("Error revoking license:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to revoke license" })
    };
  }
};
var revokeLicense_default = { handler };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
